CREATE TABLE `autocomplete_demo` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM AUTO_INCREMENT=15 ;



INSERT INTO `autocomplete_demo` VALUES (1, 'Abba');
INSERT INTO `autocomplete_demo` VALUES (2, 'The Strokes');
INSERT INTO `autocomplete_demo` VALUES (3, 'Talking Heads');
INSERT INTO `autocomplete_demo` VALUES (4, 'The Clash');
INSERT INTO `autocomplete_demo` VALUES (5, 'Madonna');
INSERT INTO `autocomplete_demo` VALUES (6, 'Arctic Monkeys');
INSERT INTO `autocomplete_demo` VALUES (7, 'David Byrne');
INSERT INTO `autocomplete_demo` VALUES (8, 'The White Stripes');
INSERT INTO `autocomplete_demo` VALUES (9, 'The Doors');
INSERT INTO `autocomplete_demo` VALUES (10, 'Jimi Hendrix');
INSERT INTO `autocomplete_demo` VALUES (11, 'The Rolling Stones');
INSERT INTO `autocomplete_demo` VALUES (12, 'The Pharcyde');
INSERT INTO `autocomplete_demo` VALUES (13, 'Muse');
INSERT INTO `autocomplete_demo` VALUES (14, 'Massive Attack');
